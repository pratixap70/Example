function myFunction() {
    window.location.href = "https://www.google.com";

}